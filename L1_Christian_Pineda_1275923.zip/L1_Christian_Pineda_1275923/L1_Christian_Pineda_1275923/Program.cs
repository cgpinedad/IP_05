﻿class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("ingrese su nombre: ");
        string Nombre = Console.ReadLine();
        Console.WriteLine("hola mundo");
        Console.WriteLine("soy "+ Nombre);
 // writeline para escribir una nueva linea, write para escribir en la misma linea
        Console.Write("hola mundo ");
        Console.Write("soy"+ Nombre);
        Console.ReadKey();
    }
}