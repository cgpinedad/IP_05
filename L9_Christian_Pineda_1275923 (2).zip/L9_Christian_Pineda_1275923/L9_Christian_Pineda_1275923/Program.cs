﻿namespace L9_Christian_Pineda_1275923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Monto = 0.0;
            double descuento = 0.0;

            Console.WriteLine("ingresar monto ");
            if (double.TryParse(Console.ReadLine(), out Monto))
            {
                if (Monto < 400)

                {
                    Console.WriteLine("monto sin descuento");
                }
                else if (Monto <= 1000)
                {
                    descuento = 0.07;
                }
                else if (Monto <= 5000)
                {
                    descuento = 0.10;
                }
                else if (Monto <= 15000)
                {
                    descuento = 0.15;
                }
                else if (Monto > 15000)
                {
                    descuento = 0.25;
                }
            descuentono:
                Console.WriteLine("posee codigo de descuento si o no");
                string codigosi = Console.ReadLine();
                if (codigosi == "si")
                {
                    descuento += 0.05;
                }
                else if (codigosi == "no")
                {
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("error, ingresar valor valido");
                    goto descuentono;
                }
            }
            double montoFinal = Monto - (Monto * descuento);
            Console.WriteLine("El monto a pagar es de: "+montoFinal);
        }
    }
}
