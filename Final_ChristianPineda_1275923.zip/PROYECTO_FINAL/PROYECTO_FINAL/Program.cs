﻿namespace PROYECTO_FINAL
//namespace EstimacionTiempoConstruccion
{
    internal class Program
    {



        static void Main(string[] args)
        {
            //Aqui empieza el programa
            Console.WriteLine("PROCESO DE ESTIMACION DE TIEMPO PARA LA CONSTRUCCION DE UNA VIVIENDA");
            Console.WriteLine();
            Console.WriteLine("Este programa está diseñado para poder tener un mejor control y organización para la realización de una vivienda, tomando en cuenta todas las variaciones posibles.");
            // Aqui lo que se busca es que se haga un menu pero solo llamando cada opcion, sin escribir algo mas
            bool salir = false;

            while (!salir)
            {
                // Aqui damos las opciones del menu principal
                Console.WriteLine("MENU PRINCIPAL");
                Console.WriteLine("Seleccione una opción");
                Console.WriteLine("1. PROCESO PRINCIPAL");
                Console.WriteLine("2. MANUAL DE USUARIO");
                Console.WriteLine("3. CREDITOS");
                Console.WriteLine("4. SALIR");

                string opcion = Console.ReadLine();

                Console.Clear(); // Limpia la pantalla
                // Aqui empieza el codigo del primer menu, que seria el menu principal
                switch (opcion)
                {
                    case "1":
                        ProcesoPrincipal();
                        // Cuando aparece asi es cuando manda a llamar el procedimiento
                        break;

                    case "2":
                        ManualDeUsuario();
                        break;

                    case "3":
                        Creditos();
                        break;

                    case "4":
                        salir = ConfirmarSalir();
                        break;

                    default: // Este es utilizado para que cuando no se ponga un numero correcto te regresa a volver a ingresar una opcion correcta
                        Console.WriteLine("ELIGE UN NUMERO VALIDO");
                        break;
                }

                Console.WriteLine();
            }

            Console.WriteLine("ADIOS, HASTA LUEGO."); // Aqui es cuando finaliza el programa como tal, te da una despedida
        }
        // Aca comienza el primer procedimiento
        static void ProcesoPrincipal()
        {
            // Tira el segundo menu, que seria el menu interno de la primera opcion del menu principal
            Console.WriteLine("PROCESO PRINCIPAL PARA LA ESTIMACION DE TIEMPO PARA UNA CONSTRUCCIÓN");
            Console.WriteLine();
            Console.WriteLine("HOLA, ESTOY LISTO PARA QUE JUNTOS PODAMOS REALIZAR LA ESTIMACION DE TIEMPO PARA LA CONSTRUCCION DE NUEVA CASA, PARA ELLO NECESITO QUE SELECCIONES LOS DATOS QUE ACONTINUACION TE PROPORCIONARE, GRACIAS.");
            Console.WriteLine();
            Console.WriteLine("TU NUEVA CASA SERA DE:");
            Console.WriteLine("0. UN NIVEL");
            Console.WriteLine("1. DOS NIVELES");
            double niveles = Convert.ToDouble(Console.ReadLine());
            Console.Clear(); // Aca limpia la pantalla
            if (niveles <= 1 && niveles >= 0) // Empieza el codigo para poder ddeterminar la cantidad de semanas a esperar para la construccion de la vivienda
            {
                // Aca comienza el menu de habitaciones
                Console.WriteLine("AHORA SIGAMOS...");
                Console.WriteLine();
                Console.WriteLine("QUE CANTIDAD DE HABITACIONES QUIERES TENER:");
                Console.WriteLine("1. UNA HABITACION");
                Console.WriteLine("2. DOS HABITACIONES");
                Console.WriteLine("3. TRES HABITACIONES");
                double habitaciones = Convert.ToDouble(Console.ReadLine());
                Console.Clear(); // Aca limpia la pantalla
                if (habitaciones < 4 && habitaciones > 0) // Aca empieza el menu de los sanitarios
                {
                    Console.WriteLine("QUE CANTIDAD DE SANITARIOS COMPLETOS QUIERES TENER:");
                    Console.WriteLine("1. UN SANITARIO");
                    Console.WriteLine("2. DOS SANITARIOS");
                    Console.WriteLine("3. TRES SANITARIOS");
                    double sanitarios = Convert.ToDouble(Console.ReadLine());
                    Console.Clear(); // Aca limpia la pantalla
                    if (sanitarios < 4 && sanitarios > 0)
                    {
                        // Aca comienza el menu del cuarto de servicio
                        Console.WriteLine("QUIERES UN CUARTO DE SERVICIO:");
                        Console.WriteLine("0. NO");
                        Console.WriteLine("1. SI");
                        double servicio = Convert.ToDouble(Console.ReadLine());
                        Console.Clear(); // Aca limpia la pantalla
                        if (servicio >= 0 && servicio <= 1)
                        {
                            // Llegando a este punto ya tenemos el resultado de las semanas y los aspectos a considerar
                            Tiempos tiempo = new Tiempos(niveles, habitaciones, servicio, sanitarios);
                            Console.WriteLine("EL VALOR ESTIMADO DE SEMANAS PARA TENER LA FINALIZACION DE TU NUEVA CASA ES DE: " + tiempo.obtertiempo().ToString() + " SEMANAS"); // resultado del calculo
                            Console.WriteLine(); // Se coloco los siguientes aspectos
                            Console.WriteLine("TOMANDO EN CUENTA QUE PARA LA ESTIMACION DE ESTE TIEMPO SE TOMO EL SIGUIENTE LISTADO COMO BASE EL CALCULO:");
                            Console.WriteLine("1. CIMIENTOS");
                            Console.WriteLine("2. ESTRUCTURA");
                            Console.WriteLine("3. INSTALACIONES");
                            Console.WriteLine("4. ACABADOS");
                            Console.WriteLine("5. TIEMPOS DE SECADO");
                            Console.WriteLine("6. ESTUDIO DE SUELO");
                            Console.WriteLine("7. PLANOS");
                            Console.WriteLine("8. DRENAJES");
                            Console.WriteLine("9. AGUA POTABLE");
                            Console.WriteLine("10. TIEMPO ESTIMADO PARA FINALIZACION DE OBRA GRIS");
                            Console.WriteLine("11. TIEMPO ESTIMADO PARA ENTRA DE LA OBRA");
                            Console.WriteLine(); // Aspectos que afectarian la estimacion
                            Console.WriteLine("SIEMPRE TENER EN CUENTA Y CONSIDERAR QUE ESTE PROGRAMA TE DARÁ UNA ESTIMACION DE TIEMPOS EN CUANTO A SITUACIONES COTIDIANAS, ES DECIR EN SITUACIONES OPTIMAS, Y QUE EXISTEN FACTORES AJENOS A LA OBRA LOS CUALES AFECTARAN ESTA ESTIMACION, POR EJEMPLO:");
                            Console.WriteLine("1. CONDICIONES CLIMATICAS");
                            Console.WriteLine("2. DEMORAS EN PERMISOS PARA CONSTRUCCION");
                            Console.WriteLine("3. PROBLEMAS FINANCIEROS");
                            Console.WriteLine("4. ESCASES DE MANO DE OBRA");
                            Console.WriteLine("5. ESCACES DE MATERIALES DE CONSTRUCCION");
                            Console.WriteLine("6. CAMBIOS DE DISEÑOS");
                            Console.WriteLine("7. FALTA DE COORDINACION PARA EQUIPO DE CONSTRUCCION");
                            Console.WriteLine("8. PROBLEMAS DE CALIDAD");
                            Console.WriteLine("9. PROBLEMAS DE ACCESO AL TERRENO");
                            Console.WriteLine("10. PROBLEMAS CON CONTRATISTAS");
                            Console.WriteLine();
                            Console.WriteLine("CON ESTO CONCLUIMOS CON NUESTRO PROGRAMA.");
                        }
                        else
                        {
                            Console.WriteLine("ELIGE UN NUMERO VALIDO");
                        }
                    }
                    else
                    {
                        Console.WriteLine("ELIGE UN NUMERO VALIDO");
                    }
                }
                else
                {
                    Console.WriteLine("ELIGE UN NUMERO VALIDO");
                }
            }
            else
            {
                Console.WriteLine("ELIGE UN NUMERO VALIDO");
            }
        }

        // Aqui comienza el segundo procedimiento
        static void ManualDeUsuario()
        {
            bool salir = false;

            while (!salir)
            {
                // Empieza el menu del manual de usuario
                Console.WriteLine("MANUAL DE USUARIO");
                Console.WriteLine("Seleccione una opción");
                Console.WriteLine("1. LISTA Y OPCIONES DE PROGRAMA");
                Console.WriteLine("2. PASOS PARA UTILIZAR EL PROGRAMA");
                Console.WriteLine("3. EXPLICACION DEL PROGRAMA");
                Console.WriteLine("4. REGRESAR A MENU PRINCIPAL");

                string opc = Console.ReadLine();

                Console.Clear(); // Limpiar la pantalla

                switch (opc)
                {
                    case "1":
                        MostrarListaOpcionesPrograma();
                        // Se utilizo este procedimiento
                        break;

                    case "2":
                        MostrarPasosUtilizarPrograma();
                        break;

                    case "3":
                        MostrarExplicacionPrograma();
                        break;

                    case "4":
                        salir = true;
                        break;

                    default:
                        Console.WriteLine("ELIGE UN NUMERO VALIDO");
                        break;
                }

                Console.WriteLine();
            }
        }
        // Comienza otro procedimiento
        static void MostrarListaOpcionesPrograma()
        {
            // Este menu  es utilizado para ver la primera opcion del manual de usuario
            Console.WriteLine("LISTA Y OPCIONES DE PROGRAMA");
            Console.WriteLine();
            Console.WriteLine("1. Casa de 1 o 2 niveles");
            Console.WriteLine("1.1. Habitaciones deseadas");
            Console.WriteLine("1.2. Sanitarios completos deseados");
            Console.WriteLine("1.3. Cuarto de servicio");
        }

        static void MostrarPasosUtilizarPrograma()
        {
            // Este menu es utilizado para la segunda opcion del manual de usuario
            Console.WriteLine("PASOS PARA UTILIZAR EL PROGRAMA");
            Console.WriteLine();
            Console.WriteLine("1. Inicio");
            Console.WriteLine("2. Mostrar el título 'Proceso de estimación de tiempo para la construcción de una vivienda'");
            Console.WriteLine("3. Mostrar 'Explicación resumida de lo que trata el programa'");
            Console.WriteLine("4. Mostrar el menú principal: '1. Proceso principal, 2. Manual de usuario, 3. Créditos, 4. Salir' y el usuario debe escoger una opción");
            Console.WriteLine("5. Si se elige la primera opción se desplegará el menú '1. Casa de un nivel, 2. Casa de dos niveles'");
            Console.WriteLine("6. Si se elige cualquiera de las 2 opciones pedirá lo siguiente '1. Una habitación, 2. Dos habitaciones, 3. Tres habitaciones y 4Cuatro habitaciones'");
            Console.WriteLine("7. Si se elige la opción 1 o 2 se pedirá el número de baños deseados");
            Console.WriteLine("8. Si se elige la opción 3 se pedirá '1. Cuarto de servicio, 2. Lavandería'");
            Console.WriteLine("9. Si se elige la opción 4 se regresará al menú principal");
        }

        static void MostrarExplicacionPrograma()
        {
            // Aca da una breve explicacion de que es el programa
            Console.WriteLine("EXPLICACION DEL PROGRAMA");
            Console.WriteLine();
            Console.WriteLine("El programa está diseñado para ayudar en la estimación del tiempo necesario para la construcción de una vivienda. Permite seleccionar el número de habitaciones, baños y otras opciones relacionadas con el proyecto de construcción. A través de un menú interactivo, el usuario puede navegar y seleccionar las opciones deseadas. El programa proporciona una estimación del tiempo requerido para completar la construcción en función de las opciones seleccionadas.");
        }

        static void Creditos()
        {
            // Estan todos lo relacionado a la informacion del programa, es decir quien los creo, cuanto tiempo se llevo para realizarlo, etc.
            Console.WriteLine("CREDITOS");
            Console.WriteLine();
            Console.WriteLine("FECHA DE CREACION DEL PROGRAMA: 07 DE OCTUBRE DEL 2023");
            Console.WriteLine();
            Console.WriteLine("HORAS INVERTIDAS: 12 HORAS");
            Console.WriteLine();
            Console.WriteLine(" ESTE PROGRAMA FUE DESARROLLADO POR:");
            Console.WriteLine();
            Console.WriteLine("Nombre:");
            Console.WriteLine("EDDI ANDRES FIGUEROA RAMIREZ");
            Console.WriteLine();
            Console.WriteLine("Carnet:");
            Console.WriteLine("1300123");
            Console.WriteLine();
            Console.WriteLine("Carrera:");
            Console.WriteLine("INGENIERIA CIVIL");
            Console.WriteLine();
            Console.WriteLine("Nombre:");
            Console.WriteLine("CHRISTIAN PINEDA DELGADO");
            Console.WriteLine();
            Console.WriteLine("Carnet:");
            Console.WriteLine("1275923");
            Console.WriteLine();
            Console.WriteLine("Carrera:");
            Console.WriteLine("INGENIERIA CIVIL");
            Console.WriteLine();
        }

        static bool ConfirmarSalir()
        {
            // Este seria la parte del codigo donde ya podrias salir del programa
            Console.WriteLine("¿ESTAS SEGURO DE QUE QUIERES SALIR? (s/n)");
            string respuesta = Console.ReadLine();

            return respuesta.ToLower() == "s";
        }
    }
    // Aqui comienza la siguiente clase, en la que esta la formula para realizar el calculo
    class Tiempos
    {
        // Aca se nombra cada una de las variables a utilizar
        private double n, h, sa, se;
        public Tiempos(double niveles, double habitaciones, double sanitarios, double servicio)
        {
            n = niveles;
            h = habitaciones;
            sa = sanitarios;
            se = servicio;
        }
        public double obtertiempo()
        {
            // Aqui se encuentra la formula del calculo
            double tiempototal = 23 + (5 * n) + (2 * h) + sa + se;
            return Math.Round(tiempototal, 0);
        }
    }
}







