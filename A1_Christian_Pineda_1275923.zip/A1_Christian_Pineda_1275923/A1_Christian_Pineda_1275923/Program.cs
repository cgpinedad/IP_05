﻿class program
{
    static void Main(string[] args)
    {
        string sNombre, sEdad, sCarrera, sCarnet;

        Console.WriteLine("ingrese su nombre: ");
        sNombre = Console.ReadLine();

        Console.WriteLine("ingrese su edad: ");
        sEdad = Console.ReadLine();

        Console.WriteLine("ingrese su carrera: ");
        sCarrera = Console.ReadLine();

        Console.WriteLine("ingrese su carnet: ");
        sCarnet = Console.ReadLine();

        Console.WriteLine("Mi segundo programa");
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carnet: " + sCarnet);

        Console.WriteLine("soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera " + sCarrera);
        Console.Write("mi numero de carnet es " + sCarnet);
        Console.ReadKey();
    }
}
