﻿namespace L7_ChristianPineda_1275923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1;
            Console.WriteLine("ejercicio 1");
            Console.WriteLine();
            Console.WriteLine("ingresar un numero entero");
            Console.WriteLine();
            n1 = int.Parse(Console.ReadLine());
            if (n1 < 0)
            {
                Console.WriteLine("el numero es negativo");
            }
            else
            {
                if(n1 == 0)
                {
                    Console.WriteLine("el numero es igual a cero");
                }
                else
                {
                    Console.WriteLine("el numero es positivo");
                }
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("ejercicio 2");
            Console.WriteLine();
            Console.WriteLine("ingresar numero de la semana");
            string n2 = Console.ReadLine();
            switch (n2)
            {
                case "1":
                    Console.WriteLine("dia lunes");
                    break;
                case "2":
                    Console.WriteLine("dia martes");
                    break;
                case "3":
                    Console.WriteLine("dia miercoles");
                    break;
                case "4":
                    Console.WriteLine("dia jueves");
                    break;
                case "5":
                    Console.WriteLine("dia viernes");
                    break;
                case "6":
                    Console.WriteLine("dia sabado");
                    break;
                default:
                    Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
                    break;
            }
        
        }
    }
}