﻿class Circulo
{


    private double Radio;
    public Circulo(double objCirculo)
    {
        Radio = objCirculo;
    }
    public double ObtenerPerimetro()
    {
        double perimetro = 2*Radio*Math.PI;
        return Math.Round(perimetro, 3);
    }
    public double ObtenerArea()
    {
        double area = Math.Pow(Radio, 2)* Math.PI;
        return Math.Round(area, 3);
    }
    public double ObtenerVolumen()
    {
        double volumen = (4 * Math.PI * Math.Pow(Radio, 3) / 3);
        return Math.Round(volumen, 3);
    }
}

class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Insertar valor del radio: ");
        double objCirculo = Convert.ToDouble(Console.ReadLine());

        Circulo objcirculo = new Circulo(objCirculo);
        Console.WriteLine("El valor del Perimetro es: " + objcirculo.ObtenerPerimetro().ToString());
        Console.WriteLine("El valor del Area es: " + objcirculo.ObtenerArea().ToString());
        Console.WriteLine("El valor del Volumen es: " + objcirculo.ObtenerVolumen().ToString());

        Console.ReadKey();
    }
}