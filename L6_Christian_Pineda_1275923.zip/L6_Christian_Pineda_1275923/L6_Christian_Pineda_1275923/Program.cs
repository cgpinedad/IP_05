﻿namespace L6_Christian_Pineda_1275923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ejercicio 1: operaciones aritmeticas");
            double n1 = 0.0;
            double n2 = 0.0;
            double suma = 0.0;
            double resta = 0.0;
            double multi = 0.0;
            double div = 0.0;
            double a = 0.0;
            double b = 0.0;
            double c = 0.0;
            double d = 0.0;
            double e = 0.0;
            double f = 0.0;
            double g = 0.0;
            double x1 = 0.0;
            double x2 = 0.0;
            Console.WriteLine();
            Console.WriteLine("ingresar primer numero");
            n1 = double.Parse(Console.ReadLine());
            Console.WriteLine("ingresar segundo numero");
            n2 = double.Parse(Console.ReadLine());
            suma = n1 + n2;
            resta = n1 - n2;
            multi = n1 * n2;
            div = n1 / n2;
            Console.WriteLine();
            Console.WriteLine(n1+" + "+n2+" = "+suma);
            Console.WriteLine(n1 + " - " + n2 + " = "+resta);
            Console.WriteLine(n1 + " * " + n2 + " = "+multi);
            Console.WriteLine(n1 + " / " + n2 + " = "+div);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("ejercicio 2: operaciones booleanas");
            Console.WriteLine();
            bool mayor = n1 > n2;
            bool menor = n1 < n2;
            bool igual = n1 == n2;
            Console.WriteLine();
            Console.WriteLine(n1+" > "+n2+" = "+mayor);
            Console.WriteLine(n1+" < "+n2+" = "+menor);
            Console.WriteLine(n1+" = "+n2+" = "+igual);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("ejercicio 3: jerarquia de operaciones");
            Console.WriteLine("ingresar primer numero");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("ingresar segundo numero");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("ingresar tercer numero");
            c = double.Parse(Console.ReadLine());
            d = (a * b) + c;
            e = a * (b + c);
            f = a / (b * c);
            g = ((3*a) + (2*b)) / Math.Pow(c, 2);
            Console.WriteLine();
            Console.WriteLine("resultado de la ecuacion (a * b) + c es "+d);
            Console.WriteLine("resultado de la ecuacion a * (b + c) es "+e);
            Console.WriteLine("resultado de la ecuacion a / (b * c) es "+f);
            Console.WriteLine("resultado de la ecuacion 3a + 2b / (c)^2 es "+g);
            Console.WriteLine();
            if (a != 0)
            {
                if ((Math.Pow(b, 2) - (4 * a * c)) >= 0)
                {
                    x1 = (-b + Math.Pow(Math.Pow(b, 2) - (4 * a * c), 1 / 2)) / (2 * a);
                    x2 = (-b - Math.Pow(Math.Pow(b, 2) - (4 * a * c), 1 / 2)) / (2 * a);
                    Console.WriteLine("los resultados de la ecuacion cuadratica son: x1="+x1+" x2="+x2);
                }
                else
                {
                    Console.WriteLine("hay un error en la ecuacion cuadratica ya que b^2 - 4ac es menor a cero");
                }
            }
            else
            {
                Console.WriteLine("hay un error en la ecuacion cuadratica ya que a es igual a cero");
            }
        }
    }
}