﻿class clase_menu
{
    static void Main(string[] args)
    {
        Console.WriteLine("programa mi proyecto");
        Console.WriteLine();
        Console.WriteLine("Seleccionar opcion");
        Console.WriteLine();
        Console.WriteLine("Menu de viviendas");
        Console.WriteLine("1. casa de un nivel");
        Console.WriteLine("2. casa de dos niveles");
        string opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine("vivienda de un nivel");
                break;
            case "2":
                Console.WriteLine("vivienda de dos niveles");
                break;
            default:
                Console.WriteLine("opcion invalida");
                break;
        }
        Console.WriteLine("selecciono opcion " + opcion);


        Console.ReadKey();

    }

}