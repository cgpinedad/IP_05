﻿namespace L8_Christian_Pineda_1275923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            string carnet;
            double monto = 0.00;
            Console.WriteLine("Problema No. 2");
            Console.WriteLine();
            Console.WriteLine("ingresar nombre");
            nombre = Console.ReadLine();
            Console.WriteLine("ingresar numero de carnet");
            carnet = Console.ReadLine();
            Console.WriteLine("hola "+nombre+" - "+carnet);
            Console.WriteLine();
            inicio: 
            Console.WriteLine("ingresar un monto de quetzales entre 0 Y 999.99");
            monto = double.Parse(Console.ReadLine());
            if (monto <= 999.99 && monto >= 0.00)
            {
                double x = 0;
                int billete100 = 0;
                int billete50 = 0;
                int billete20 = 0;
                int billete10 = 0;
                int billete5 = 0;
                int monedaq = 0;
                int moneda25 = 0;
                int moneda1 = 0;
                x = monto * 100;
                billete100 = (int)(x / 10000);
                x %= 10000;
                billete50 = (int)(x / 5000);
                x %= 5000;
                billete20 = (int)(x / 2000);
                x %= 2000;
                billete10 = (int)(x / 1000);
                x %= 1000;
                billete5 = (int)(x / 500);
                x %= 500;
                monedaq = (int)(x / 100);
                x %= 100;
                moneda25 = (int)(x / 25);
                x %= 25;
                moneda1 = (int)(x / 1);
                x %= 1;
                Console.WriteLine(billete100 + "billetes de Q100");
                Console.WriteLine(billete50 + "billete de Q50");
                Console.WriteLine(billete20 + "billete de Q20");
                Console.WriteLine(billete10 + "billete de Q10");
                Console.WriteLine(billete5 + "billete Q5");
                Console.WriteLine(monedaq + "moneda de Q1");
                Console.WriteLine(moneda25 + "moneda de Q0.25 ");
                Console.WriteLine(moneda1 + "moneda de Q0.01");
            }
            else
            {
                Console.WriteLine("ingresar monto valido");
                goto inicio;
            }
        }
    }
}