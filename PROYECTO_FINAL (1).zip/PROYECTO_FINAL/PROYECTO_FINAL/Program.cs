﻿namespace PROYECTO_FINAL
{
    internal class Program
    {
        static void Main(string[] args)

        {
            Console.WriteLine("PROCESO DE ESTIMACION DE TIEMPO PARA LA CONSTRUCCION DE UNA VIVIENDA");

            Console.WriteLine();
            Console.WriteLine("Este programa esta diseñado para poder tener un mejor control y organizacion para la realizacion de una vivienda, tomando en cuenta todas las variaciones posibles.");

        SALTO1:
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine(" Seleccione una opción");
            Console.WriteLine(" 1. PROCESO PRINCIPAL ");
            Console.WriteLine(" 2. MANUAL DE USUARIO ");
            Console.WriteLine(" 3. CREDITOS");
            Console.WriteLine(" 4. SALIR");
            string opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":
                    Console.WriteLine(" PROCESO PRINCIPAL PARA LA ESTIMACION DE TIEMPO PARA UNA CONSTRUCCIÓN ");
                    break;

                case "2":
                    SALTO3:
                    Console.WriteLine(" MANUAL DE USUARIO ");
                    Console.WriteLine(" Seleccione una opción");
                    Console.WriteLine(" 1. LISTA Y OPCIONES DE PROGRAMA ");
                    Console.WriteLine(" 2. PASOS PARA UTILIZAR EL PROGRAMA ");
                    Console.WriteLine(" 3. EXPLICACION DEL PROGRAMA");
                    Console.WriteLine(" 4. REGRESAR A MENU PRINCIPAL");
                    string opc = Console.ReadLine();
                    switch (opc)
                    {
                        case "1":
                            Console.WriteLine(" LISTA Y OPCIONES DE PROGRAMA ");
                            Console.WriteLine();
                            Console.WriteLine("1. Casa de 1 o 2 niveles ");
                            Console.WriteLine("1.1. Cuartos deseados");
                            Console.WriteLine("1.2. Baños deseados");
                            Console.WriteLine("1.3. Cuarto de servicio o lavanderia");

                            SALTO4:
                            Console.WriteLine();
                            Console.WriteLine(" ¿Deseas Salir? ");
                            Console.WriteLine(" Seleccione una opción");
                            Console.WriteLine("1. Si, estoy seguro.");
                            Console.WriteLine("2. No, no quiero salir.");
                            string salida2 = Console.ReadLine();
                            switch (salida2)
                            {
                                case "1":
                                    Console.WriteLine(" Adios, hasta luego.");
                                    break;
                                case "2":
                                    goto SALTO1;
                                default:
                                    Console.WriteLine("Elige un numero valido");
                                    goto SALTO4;
                                   
                            }
                            break;

                        case "2":
                            Console.WriteLine("PASOS PARA UTILIZAR EL PROGRAMA ");
                            Console.WriteLine();
                            Console.WriteLine("1. Inicio ");
                            Console.WriteLine("2. Mostrar el título “Proceso de estimación de tiempo para la construcción de una vivienda”.");
                            Console.WriteLine("3. Mostrar “Explicación resumida de lo que trata el programa”. ");
                            Console.WriteLine("4. Mostrar el menú principal: “1. Proceso principal, 2. Manual de usuario, 3. Créditos, 4. Salir” y el usuario debe escoger una opción. ");
                            Console.WriteLine("5. Si se elige la primera opción se desplegará el menú “1. Casa de un nivel, 2. Casa de dos niveles”. ");
                            Console.WriteLine("6. Si se elige cualquiera de las 2 opciones pedirá lo siguiente “1. Una habitación, 2. Dos habitaciones, 3. Tres habitaciones y 4. Cuatro habitaciones”. Y el usuario deberá escoger una opción. ");
                            Console.WriteLine("7. Si se elige cualquiera de las 4 opciones pedirá lo siguiente “1. Un baño, 2. Dos baños, 3. Tres baños y 4. Cuatro baños”. Y el usuario deberá escoger una opción. ");
                            Console.WriteLine("8. Si se elige cualquiera de las 4 opciones pedirá si desea cuarto de servicio o lavandería “1. Si y 2. No”");
                            Console.WriteLine("9. Mostrar “1. Resultados, 2. Regresar a menú anterior, 3. Regresar a menú principal y 4. Salir”. ");
                            Console.WriteLine("10. Fin");

                        SALTO5:
                            Console.WriteLine();
                            Console.WriteLine(" ¿Deseas Salir? ");
                            Console.WriteLine(" Seleccione una opción");
                            Console.WriteLine("1. Si, estoy seguro.");
                            Console.WriteLine("2. No, no quiero salir.");
                            string salida3 = Console.ReadLine();
                            switch (salida3)
                            {
                                case "1":
                                    Console.WriteLine(" Adios, hasta luego.");
                                    break;
                                case "2":
                                    goto SALTO1;
                                default:
                                    Console.WriteLine("Elige un numero valido");
                                    goto SALTO5;

                            }
                            break;
                        case "3":
                            Console.WriteLine(" EXPLICACION DEL PROGRAMA");
                            Console.WriteLine();
                            Console.WriteLine("Crear un proceso de estimación para una construcción implica varios procesos y varios pasos, los cuales son fundamentales debido a que dentro de la construcción se tendrá personas viviendo y tendría que cumplir con todas las normas. ");
                            Console.WriteLine();
                            Console.WriteLine("Para poder realizarlo se tendrá que ver los siguientes aspectos: ");
                            Console.WriteLine();
                            Console.WriteLine("1. Cimientos ");
                            Console.WriteLine("2. Estructura");
                            Console.WriteLine("3. Instalaciones");
                            Console.WriteLine("4. Acabados");
                            Console.WriteLine("5. Tiempos de secado");
                            Console.WriteLine("6. Especificaciones del cliente");
                            Console.WriteLine("7. Estudio de suelo");
                            Console.WriteLine("8. Planos");
                            Console.WriteLine("9. Drenajes");
                            Console.WriteLine("10. Agua potable");
                            Console.WriteLine("11. Tiempo estimado para finalizacion de obra gris");
                            Console.WriteLine("12. Tiempo estimado para la entrega de la obra");
                            Console.WriteLine();
                            Console.WriteLine("Posteriormente se tendrá que establecer todas las estimaciones de duración para cada tarea. ");
                            Console.WriteLine();
                            Console.WriteLine("Para poder llevar a cabo el tiempo se podría utilizar los Diagramas de Gantt o buscar otro tipo que facilite la programación de las actividades. ");
                            Console.WriteLine();
                            Console.WriteLine("También se tendrá que tomar en cuenta que existirán retrasos imprevistos y hacer los cálculos adecuados para que esto no afecten en la obra final ni los tiempos. ");

                        SALTO6:
                            Console.WriteLine();
                            Console.WriteLine(" ¿Deseas Salir? ");
                            Console.WriteLine(" Seleccione una opción");
                            Console.WriteLine("1. Si, estoy seguro.");
                            Console.WriteLine("2. No, no quiero salir.");
                            string salida4 = Console.ReadLine();
                            switch (salida4)
                            {
                                case "1":
                                    Console.WriteLine(" Adios, hasta luego.");
                                    break;
                                case "2":
                                    goto SALTO1;
                                default:
                                    Console.WriteLine("Elige un numero valido");
                                    goto SALTO6;

                            }
                            break;
                        case "4":
                            goto SALTO1;

                        default:
                            Console.WriteLine("Elige un valor valido");
                            goto SALTO3; 

                    }

                    break;

                case "3":
                    Console.WriteLine(" CREDITOS ");
                    Console.WriteLine();
                    Console.WriteLine("PROCESO DE ESTIMACION DE TIEMPO PARA LA CONSTRUCCION DE UNA VIVIENDA");
                    Console.WriteLine();
                    Console.WriteLine("Fecha de creacion: 07 de octubre del 2023");
                    Console.WriteLine();
                    Console.WriteLine("Horas invertidas: 8 horas");
                    Console.WriteLine();
                    Console.WriteLine(" CREADORES ");
                    Console.WriteLine();
                    Console.WriteLine("Nombre:");
                    Console.WriteLine("EDDI ANDRES FIGUEROA RAMIREZ");
                    Console.WriteLine();
                    Console.WriteLine("Carnet:");
                    Console.WriteLine("1300123");
                    Console.WriteLine();
                    Console.WriteLine("Carrera:");
                    Console.WriteLine("INGENIERIA CIVIL");
                    Console.WriteLine();
                    Console.WriteLine("Nombre:");
                    Console.WriteLine("CHRISTIAN PINEDA DELGADO");
                    Console.WriteLine();
                    Console.WriteLine("Carnet:");
                    Console.WriteLine("1275923");
                    Console.WriteLine();
                    Console.WriteLine("Carrera:");
                    Console.WriteLine("INGENIERIA CIVIL");
                    Console.WriteLine();
                    goto SALTO2;

                case "4":
                SALTO2:
                    Console.WriteLine();
                    Console.WriteLine(" ¿Seguro que quieres Salir? ");
                    Console.WriteLine(" Seleccione una opción");
                    Console.WriteLine("1. Si, estoy seguro.");
                    Console.WriteLine("2. No, no quiero salir.");
                    string salida = Console.ReadLine();
                    switch (salida)
                    {
                        case "1":
                            Console.WriteLine(" Adios, hasta luego.");
                            break;
                        case "2":
                            goto SALTO1;
                        default:
                            Console.WriteLine("Elige un numero valido");
                            goto SALTO2;

                    }
                    break;
                default:
                    Console.WriteLine("Elige un numero valido");
                    goto SALTO1;
            }
        }
    }
}







